function [N, t] = setN(TIME)

t = unique(TIME);
N = numel(t);